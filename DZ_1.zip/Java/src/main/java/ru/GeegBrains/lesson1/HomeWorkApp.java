package ru.GeegBrains.lesson1;

public class HomeWorkApp {
    public static void main (String[] args){
        System.out.println("Hello! Welcome to Java 16");
        printThreeWords();
        checkSumSign();
        printColor();
        compareNumbers();
    }
    public static void printThreeWords() {
        System.out.println("_Orange");
        System.out.println("_Banana");
        System.out.println("_Apple");
    }
    public static void checkSumSign() {
        int a, b;
        a=b=10;
        int c = (a + b);
        if (c > 0) {
            System.out.println("positive sum");
        }
        if (c < 0) {
            System.out.println("negative sum");
        }

    }
    public static void printColor() {
        int value;
        value=10;
        if (value>0 && value<100) {
            System.out.println("yellow");
        }
        else if (value <= 0){
            System.out.println("red");
        }
        else if (value <= 0){
            System.out.println("red");
        }
        else if (value < 100){
            System.out.println("green");
        }

    }
    public static void compareNumbers() {
        int a, b;
        a = b = 10;

        if (a >= b) {
            System.out.println("a >= b");
        } else {
            System.out.println("a < b");
        }
    }
}
